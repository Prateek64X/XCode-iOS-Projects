//
//  ViewController.swift
//  UI Scroll View
//
//  Created by Prateek Panwar on 01/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

