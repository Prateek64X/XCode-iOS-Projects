//
//  ViewController.swift
//  Date Picker
//
//  Created by Prateek Panwar on 09/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var textField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        textField.text = formatter.string(from: date)
        textField.textColor = .blue
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.addTarget(self, action: #selector(datePickerValueChange(sender:)), for: UIControl.Event.editingChanged)
        datePicker.frame.size = CGSize(width: 0, height: 250)
        textField.inputView = datePicker
    }
    
    @objc func datePickerValueChange(sender: UIDatePicker)
    {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        textField.text = formatter.string(from: sender.date)
        
    }

}

