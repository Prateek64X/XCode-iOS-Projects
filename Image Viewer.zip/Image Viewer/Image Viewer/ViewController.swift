//
//  ViewController.swift
//  Image Viewer
//
//  Created by Prateek Panwar on 09/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var imageNumber = 1
    @IBOutlet var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.backgroundColor = .black
        imageView.image = UIImage(named: "Image")
    }

    @IBAction func nextbut(_ sender: Any) {
        
        imageNumber = imageNumber+1
        switch imageNumber {
        case 1:
            imageView.image = UIImage(named: "Image")
        case 2:
            imageView.image = UIImage(named: "Image-1")
        case 3:
            imageView.image = UIImage(named: "Image-2")
            imageNumber = 0
        default:
            imageView.image = UIImage(named: "Image")
        }
    }
}

