//
//  ViewController.swift
//  UI Alert Controller
//
//  Created by Prateek Panwar on 23/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func showAlrtClick(_ sender: UIButton) {
        let alert = UIAlertController(title: "Who's there", message: "I'm alerting you, Don't click that button again!", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title:"Cancel", style: .cancel, handler: {(action) in print("Cancel")}))
        alert.addAction(UIAlertAction(title:"Default", style: .default, handler: {(action) in print("Default")}))
        alert.addAction(UIAlertAction(title:"Destructive", style: .destructive, handler: {(action) in print("Destructive")}))
           
        self.present(alert, animated: true)
    }
    
}

