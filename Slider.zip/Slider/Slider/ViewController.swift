//
//  ViewController.swift
//  Slider
//
//  Created by Prateek Panwar on 09/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var imageView = UIImageView()
    var size: CGFloat = 125
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView.backgroundColor = .red
        imageView.frame = CGRect(x: 0, y: 0, width: size, height: size)
        imageView.center = view.center
        self.view.addSubview(imageView)    }
    
    
    @IBAction func sliderDidSlide(_ sender: UISlider) {
        let value = sender.value

        imageView.frame = CGRect(x: 0, y: 0, width: size * CGFloat(value), height: size * CGFloat(value))
        imageView.center = view.center
        
    }


}

