//
//  ViewController.swift
//  Switches
//
//  Created by Prateek Panwar on 30/11/21.
//  Copyright © 2021 Prateek Panwar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var mySwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func switchDidChange(_ sender: UISwitch){
        if sender.isOn{
            view.backgroundColor = .red
        }
        else {
            view.backgroundColor = .blue
        }

}
}
